function getRandomAttackValue(attack){						
	attack = attack + 1;    					
	var random = Math.floor(Math.random()*attack);  			
	return random;					
}