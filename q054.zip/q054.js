var orc = new Monster("해적왕", 130, 75);
var elf = new Player("루피", 50, 240);


function fight() {
    
    battle();
    battle();
    battle();

}





